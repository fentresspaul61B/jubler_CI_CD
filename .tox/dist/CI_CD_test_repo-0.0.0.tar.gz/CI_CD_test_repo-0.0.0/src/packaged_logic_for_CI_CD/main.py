def func1(num: float) -> float:
    """Multiply the num by 2."""
    return num * 2


def func2(num: float) -> float:
    """Square the num."""
    return num ** 2
