# mentia_CI_CD_test
![Tests](https://github.com/fentresspaul61B/mentia_CI_CD_test/actions/workflows/tests.yml/badge.svg)

This repo serves as a template for setting up CI/CD automated testing.
